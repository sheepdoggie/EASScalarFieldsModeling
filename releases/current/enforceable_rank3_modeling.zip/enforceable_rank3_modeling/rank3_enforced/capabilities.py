from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Iterable


FRAMEWORK_VERSION = "0.1.4"
FRAMEWORK_RELEASE_LABEL = "0.1.4-release-guard"

FRAMEWORK_CAPABILITIES: frozenset[str] = frozenset(
    {
        "declarative_overlay_only",
        "signed_evidence_envelope",
        "explicit_path_construction",
        "center_locus_readout",
        "structural_silence_readout",
        "delta_l_classification",
        "SOO_FUNCTIONAL_REPORT",
        "soo_functional_hash",
        "diagnostic_point_residual_samples",
        "relation_complete_packet_contrast",
        "dual_plaintext_encrypted_output",
        "support_seeded_initialization",
        "signed_release_manifest_guard",
        "version_guard_environment_cache",
        "configuration_only_job_bundles",
    }
)


@dataclass(frozen=True)
class CapabilityReport:
    framework_version: str
    framework_release_label: str
    capabilities: tuple[str, ...]
    required_capabilities: tuple[str, ...]
    missing_capabilities: tuple[str, ...]
    passed: bool

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def capability_report(required: Iterable[str] = ()) -> CapabilityReport:
    required_tuple = tuple(sorted(set(str(x) for x in required)))
    missing = tuple(x for x in required_tuple if x not in FRAMEWORK_CAPABILITIES)
    return CapabilityReport(
        framework_version=FRAMEWORK_VERSION,
        framework_release_label=FRAMEWORK_RELEASE_LABEL,
        capabilities=tuple(sorted(FRAMEWORK_CAPABILITIES)),
        required_capabilities=required_tuple,
        missing_capabilities=missing,
        passed=not missing,
    )


def require_capabilities(required: Iterable[str]) -> CapabilityReport:
    report = capability_report(required)
    if not report.passed:
        raise RuntimeError(
            "Framework is missing required capabilities: " + ", ".join(report.missing_capabilities)
        )
    return report
