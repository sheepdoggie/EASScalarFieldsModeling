from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from .fingerprints import array_hash, stable_json_hash
from .soo_execution import SOOExecutionReport


@dataclass(frozen=True)
class ResponseBurdenReport:
    report_schema: str
    burden_rule_id: str
    input_execution_report_hash: str
    burden_value: float
    burden_vector_hash: str
    scalar_field_native: bool
    interface_facing: bool
    exploratory: bool
    details: dict[str, Any]

    def fingerprint(self) -> str:
        return stable_json_hash(asdict(self))


def build_response_burden_report(
    *,
    execution_report: SOOExecutionReport,
    burden_rule_id: str = "soo_residual_burden_v0",
) -> ResponseBurdenReport:
    residuals = np.array([step.soo_residual_l2 for step in execution_report.step_reports], dtype=np.float64)
    if burden_rule_id == "soo_residual_burden_v0":
        value = float(np.sum(residuals ** 2))
        scalar_native = True
        interface_facing = False
        exploratory = False
        details = {"definition": "Sum of squared association-indexed SOO equation residual norms over executed steps."}
    elif burden_rule_id == "cyclic_return_burden_v0":
        value = 0.0
        scalar_native = True
        interface_facing = False
        exploratory = True
        details = {"definition": "Placeholder cyclic-return burden; requires automorphic-class metric before admission."}
    elif burden_rule_id == "charge_packet_burden_v0":
        value = 0.0
        scalar_native = False
        interface_facing = True
        exploratory = True
        details = {"definition": "Placeholder charge packet burden; must not be sole stiffness selector for candidate/admission."}
    else:
        value = float(np.sum(residuals ** 2))
        scalar_native = False
        interface_facing = False
        exploratory = True
        details = {"warning": f"Unknown burden_rule_id {burden_rule_id!r}; classified exploratory."}
    return ResponseBurdenReport(
        report_schema="rank3_response_burden_report_v1",
        burden_rule_id=str(burden_rule_id),
        input_execution_report_hash=execution_report.fingerprint(),
        burden_value=value,
        burden_vector_hash=array_hash(residuals),
        scalar_field_native=scalar_native,
        interface_facing=interface_facing,
        exploratory=exploratory,
        details=details,
    )
