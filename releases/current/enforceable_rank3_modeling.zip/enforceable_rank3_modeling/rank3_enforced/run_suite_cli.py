from __future__ import annotations

import argparse
import json
from pathlib import Path

from .run_manager import BUILTIN_SUITES, default_signing_key, run_overlay_suite


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a built-in or external overlay suite using the installed framework package.")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("suite_id", nargs="?", choices=sorted(BUILTIN_SUITES.keys()), help="Built-in suite ID")
    source.add_argument("--overlays-dir", help="Directory containing external overlay JSON files")
    parser.add_argument("--output-root", required=True, help="Output root for suite results")
    parser.add_argument("--signing-key", default=str(default_signing_key()), help="Private signing key path. Default: ~/.rank3/private_key.pem")
    parser.add_argument("--continue-on-failure", action="store_true", help="Continue running later overlays after a failure")
    parser.add_argument("--debug", action="store_true", help="Explicitly enable run-debugging instrumentation for each overlay in the suite")
    parser.add_argument("--debug-depth", type=int, default=1, help="Rank-3 association neighborhood depth for --debug. Default: 1")
    parser.add_argument("--debug-max-points", type=int, default=256, help="Maximum debug neighborhood points for --debug. Default: 256")
    parser.add_argument("--quiet", action="store_true", help="Suppress progress messages; final JSON report is still printed")
    args = parser.parse_args(argv)
    report = run_overlay_suite(
        suite_id=args.suite_id,
        overlays_dir=Path(args.overlays_dir) if args.overlays_dir else None,
        output_root=Path(args.output_root),
        private_key_path=Path(args.signing_key),
        fail_fast=not args.continue_on_failure,
        progress=not args.quiet,
        debug=args.debug,
        debug_depth=args.debug_depth,
        debug_max_points=args.debug_max_points,
    )
    print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
    return 0 if report.failed_count == 0 and report.passed_count == report.overlay_count else 1


if __name__ == "__main__":
    raise SystemExit(main())
