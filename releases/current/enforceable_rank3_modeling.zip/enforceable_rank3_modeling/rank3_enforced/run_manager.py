from __future__ import annotations

import json
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from importlib import resources
from pathlib import Path
from typing import Iterable, Sequence

from .certified_runner import run_declarative_overlay
from .fingerprints import file_hash, stable_json_hash
from .package_manifest import default_environment_record, package_and_sign_enforced_result
from .signing import verify_certificate
from .version_guard import enforce_latest_release_guard

BUILTIN_SUITE_ROOT = "overlay_suites"


@dataclass(frozen=True)
class BuiltinSuite:
    suite_id: str
    description: str
    required_artifacts: tuple[str, ...]


BUILTIN_SUITES: dict[str, BuiltinSuite] = {
    "charge_same_opposite_association_indexed": BuiltinSuite(
        suite_id="charge_same_opposite_association_indexed",
        description="L16-L32 same/opposite charge support path overlays using association-indexed SOO and two-ledger initialization.",
        required_artifacts=(
            "CERTIFICATE.json",
            "EVIDENCE_ENVELOPE.json",
            "INITIAL_TWO_LEDGER_REPORT.json",
            "OPTIONAL_MODULE_REPORT.json",
            "SOO_EXECUTION_REPORT.json",
            "CYCLIC_RETURN_REPORT.json",
            "STIFFNESS_INPUT_REPORT.json",
            "RESPONSE_BURDEN_REPORT.json",
            "INDUCED_STIFFNESS_REPORT.json",
            "STIFFNESS_CLOSURE_REPORT.json",
            "STIFFNESS_FEEDBACK_REPORT.json",
            "SOO_FUNCTIONAL_REPORT.json",
        ),
    )
}


@dataclass(frozen=True)
class OverlayRunRecord:
    case_id: str
    overlay_path: str
    output_dir: str
    status: str
    certificate_valid: bool | None
    base_gate_passed: bool | None
    external_verdict: str | None
    missing_required_artifacts: tuple[str, ...]
    error: str | None = None


@dataclass(frozen=True)
class SuiteRunReport:
    suite_id: str
    started_utc: str
    finished_utc: str
    output_root: str
    overlay_count: int
    passed_count: int
    failed_count: int
    release_guard_passed: bool
    release_guard_cache: str | None
    records: tuple[OverlayRunRecord, ...]
    report_hash: str

    def to_dict(self) -> dict[str, object]:
        d = asdict(self)
        return d


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_signing_key() -> Path:
    return Path.home() / ".rank3" / "private_key.pem"


def suite_resource_files(suite_id: str) -> list[Path]:
    if suite_id not in BUILTIN_SUITES:
        raise ValueError(f"Unknown built-in suite: {suite_id}")
    suite_res = resources.files("rank3_enforced").joinpath(BUILTIN_SUITE_ROOT, suite_id)
    paths: list[Path] = []
    with resources.as_file(suite_res) as suite_path:
        if not suite_path.exists():
            raise FileNotFoundError(f"Built-in suite resources not found: {suite_id}")
        paths = sorted(Path(suite_path).glob("*.json"))
    return paths


def overlay_files_from_source(*, suite_id: str | None = None, overlays_dir: str | Path | None = None) -> list[Path]:
    if suite_id and overlays_dir:
        raise ValueError("Use either suite_id or overlays_dir, not both.")
    if suite_id:
        return suite_resource_files(suite_id)
    if overlays_dir is None:
        raise ValueError("Either suite_id or overlays_dir is required.")
    root = Path(overlays_dir)
    files = sorted(root.glob("*.json"))
    if not files:
        raise FileNotFoundError(f"No JSON overlays found in {root}")
    return files


def list_builtin_suites() -> list[dict[str, object]]:
    rows = []
    for suite_id, suite in sorted(BUILTIN_SUITES.items()):
        count = 0
        try:
            count = len(suite_resource_files(suite_id))
        except Exception:
            count = -1
        rows.append(
            {
                "suite_id": suite_id,
                "description": suite.description,
                "overlay_count": count,
                "required_artifacts": list(suite.required_artifacts),
            }
        )
    return rows


def write_workspace(path: str | Path) -> Path:
    root = Path(path).resolve()
    root.mkdir(parents=True, exist_ok=True)
    (root / "runs").mkdir(exist_ok=True)
    (root / "logs").mkdir(exist_ok=True)
    (root / "SUITES.json").write_text(json.dumps(list_builtin_suites(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (root / "README.md").write_text(
        "# Rank-3 Run Workspace\n\n"
        "This workspace is intentionally code-free. Do not copy `rank3_enforced/` here.\n\n"
        "Use installed console commands, for example:\n\n"
        "```bash\n"
        "rank3-check-release-guard --force-refresh\n"
        "rank3-list-suites\n"
        "rank3-run-suite charge_same_opposite_association_indexed --output-root runs/charge_assoc --signing-key ~/.rank3/private_key.pem\n"
        "```\n\n"
        "The run manager loads built-in overlays from the installed package and writes signed evidence packages under `runs/`.\n",
        encoding="utf-8",
    )
    return root


def run_signed_overlay_case(
    *,
    overlay_path: str | Path,
    output_dir: str | Path,
    private_key_path: str | Path | None = None,
    release_guard_cache_dir: str | Path | None = None,
    command: str = "rank3-run-overlay",
    required_artifacts: Sequence[str] = (),
) -> OverlayRunRecord:
    overlay = Path(overlay_path)
    output = Path(output_dir)
    key = Path(private_key_path) if private_key_path is not None else default_signing_key()
    cache_dir = Path(release_guard_cache_dir) if release_guard_cache_dir is not None else output.parent
    case_id = output.name
    try:
        guard_report = enforce_latest_release_guard(run_kind="candidate", cache_dir=cache_dir)
        result = run_declarative_overlay(overlay)
        environment = default_environment_record()
        environment["release_guard"] = guard_report.to_dict()
        environment["overlay_file_sha256"] = file_hash(overlay)
        package_and_sign_enforced_result(
            result=result,
            output_dir=output,
            private_key_path=key,
            overlay_path=overlay,
            command=command,
            environment=environment,
        )
        verification = verify_certificate(output)
        missing = tuple(name for name in required_artifacts if not (output / name).is_file())
        status = "passed" if verification.valid and not missing else "failed"
        return OverlayRunRecord(
            case_id=case_id,
            overlay_path=str(overlay),
            output_dir=str(output),
            status=status,
            certificate_valid=verification.valid,
            base_gate_passed=bool(result.gate.passed),
            external_verdict=str(result.gate.external_admission_verdict.value),
            missing_required_artifacts=missing,
            error=None if status == "passed" else "Missing required artifacts or invalid certificate.",
        )
    except Exception as exc:
        output.mkdir(parents=True, exist_ok=True)
        error_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        (output / "RUN_ERROR.txt").write_text(error_text, encoding="utf-8")
        return OverlayRunRecord(
            case_id=case_id,
            overlay_path=str(overlay),
            output_dir=str(output),
            status="failed",
            certificate_valid=None,
            base_gate_passed=None,
            external_verdict=None,
            missing_required_artifacts=tuple(required_artifacts),
            error=error_text,
        )


def run_overlay_suite(
    *,
    suite_id: str | None = None,
    overlays_dir: str | Path | None = None,
    output_root: str | Path,
    private_key_path: str | Path | None = None,
    fail_fast: bool = True,
    required_artifacts: Sequence[str] | None = None,
) -> SuiteRunReport:
    started = _now_utc()
    overlays = overlay_files_from_source(suite_id=suite_id, overlays_dir=overlays_dir)
    output_root_path = Path(output_root).resolve()
    output_root_path.mkdir(parents=True, exist_ok=True)
    guard = enforce_latest_release_guard(run_kind="candidate", cache_dir=output_root_path)
    (output_root_path / "release_guard.json").write_text(json.dumps(guard.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")

    if required_artifacts is None:
        if suite_id and suite_id in BUILTIN_SUITES:
            required_artifacts = BUILTIN_SUITES[suite_id].required_artifacts
        else:
            required_artifacts = ("CERTIFICATE.json", "EVIDENCE_ENVELOPE.json")

    records: list[OverlayRunRecord] = []
    suite_label = suite_id or f"external:{Path(overlays_dir).resolve()}"
    for overlay in overlays:
        case_id = overlay.stem
        record = run_signed_overlay_case(
            overlay_path=overlay,
            output_dir=output_root_path / "runs" / case_id,
            private_key_path=private_key_path,
            release_guard_cache_dir=output_root_path,
            command=f"rank3-run-suite {suite_label}",
            required_artifacts=required_artifacts,
        )
        records.append(record)
        if record.status != "passed" and fail_fast:
            break

    passed_count = sum(1 for r in records if r.status == "passed")
    failed_count = sum(1 for r in records if r.status != "passed")
    finished = _now_utc()
    payload_for_hash = {
        "suite_id": suite_label,
        "started_utc": started,
        "finished_utc": finished,
        "output_root": str(output_root_path),
        "records": [asdict(r) for r in records],
    }
    report = SuiteRunReport(
        suite_id=suite_label,
        started_utc=started,
        finished_utc=finished,
        output_root=str(output_root_path),
        overlay_count=len(overlays),
        passed_count=passed_count,
        failed_count=failed_count,
        release_guard_passed=guard.passed,
        release_guard_cache=str(guard.cache_path) if guard.cache_path else None,
        records=tuple(records),
        report_hash=stable_json_hash(payload_for_hash),
    )
    (output_root_path / "SUITE_RUN_REPORT.json").write_text(json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")

    # Write package-level SHA256 sums for easy transfer verification.
    sums: list[str] = []
    for path in sorted(p for p in output_root_path.rglob("*") if p.is_file()):
        rel = path.relative_to(output_root_path)
        if rel.as_posix() == "SHA256SUMS.csv":
            continue
        sums.append(f"{file_hash(path)}  {rel.as_posix()}")
    (output_root_path / "SHA256SUMS.csv").write_text("\n".join(sums) + "\n", encoding="utf-8")
    return report
