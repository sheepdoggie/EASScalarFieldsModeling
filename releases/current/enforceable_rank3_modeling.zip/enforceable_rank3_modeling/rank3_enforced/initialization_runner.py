from __future__ import annotations

from dataclasses import replace
import numpy as np

import scalar_field_geometry as sfg
from .exceptions import ManifestError
from .fingerprints import array_hash, stable_json_hash
from .initialization_sources import build_initialization_source_array
from .initialization_trace import InitializationEpochReport, InitializationResult
from .overlay_schema import InitializationSpec, SupportSpec
from .soo_compiler import build_declarative_soo_update_rule
from .soo_schema import SOORecipe


def recipe_uses_support_initialization_source(recipe: SOORecipe) -> bool:
    return any(term.operator_id == "support_initialization_source" for term in recipe.residual_terms)


def strip_support_initialization_terms(recipe: SOORecipe) -> SOORecipe:
    """Remove initialization-only source terms from the measurement recipe."""

    residual_terms = tuple(
        term for term in recipe.residual_terms if term.operator_id != "support_initialization_source"
    )
    if not residual_terms:
        raise ManifestError(
            "SOO measurement recipe would be empty after removing support_initialization_source. "
            "Add at least one measurement residual term."
        )
    return replace(recipe, residual_terms=residual_terms)


def run_initialization_epoch(
    *,
    initialization: InitializationSpec,
    initial_state: sfg.FrozenAssociationState,
    initial_phi: sfg.FloatArray,
    supports: tuple[SupportSpec, ...],
    graph_mode: str,
    path_scope: str,
    phase_rule,
    pair_weight_rule,
    triplet_lift_rule,
    soo_recipe: SOORecipe | None,
    path_construction_report: object | None = None,
) -> InitializationResult:
    """Execute the locked initialization epoch and return measurement phi_0.

    The epoch is evidence-bearing but readout-silent. Measurement readouts start
    only after this function produces phi_after_initialization.
    """

    phi = np.asarray(initial_phi, dtype=np.float64).copy()
    if phi.shape != (initial_state.n_points,):
        raise ManifestError(
            f"initial_phi shape {phi.shape} does not match n_points={initial_state.n_points}."
        )

    source_array, source_trace = build_initialization_source_array(
        initialization=initialization,
        supports=supports,
        n_points=initial_state.n_points,
    )

    if not source_trace.passed:
        raise ManifestError(f"Initialization source validation failed: {source_trace.details}")

    if initialization.mode == "support_seeded":
        if soo_recipe is None:
            raise ManifestError("support_seeded initialization requires soo_declarative_v0_1 recipe.")
        # The sealed support source provides the non-vacuum starting record.
        # It is applied before SOO initialization cycles so all-zero vacuum does
        # not have to invent structure.
        phi = phi + source_array
    elif initialization.mode == "vacuum_zero":
        # No additional source. This is a null-control-compatible start.
        pass
    elif initialization.mode == "explicit_phi":
        # Explicit initial_phi is already present and hashed.
        pass
    else:
        raise ManifestError(f"Unsupported initialization.mode: {initialization.mode}")

    states = [initial_state]
    init_traces = ()

    if initialization.initialization_cycles > 0:
        if soo_recipe is None:
            raise ManifestError("initialization_cycles > 0 requires soo_declarative_v0_1 recipe.")
        init_rule = build_declarative_soo_update_rule(
            soo_recipe,
            boundary_source_array=source_array if recipe_uses_support_initialization_source(soo_recipe) else None,
            boundary_source_hash=source_trace.source_hash if recipe_uses_support_initialization_source(soo_recipe) else None,
            epoch_label="initialization",
            supports=supports,
            path_construction_report=path_construction_report,
        )
        init_config = sfg.ScalarFieldGeometryConfig(
            initial_state=initial_state,
            initial_phi=phi,
            n_layers=initialization.initialization_cycles + 1,
            graph_mode=graph_mode,  # type: ignore[arg-type]
            path_scope=path_scope,  # type: ignore[arg-type]
            phase_rule=phase_rule,
            pair_weight_rule=pair_weight_rule,
            triplet_lift_rule=triplet_lift_rule,
            scalar_update_rule=init_rule,
            association_remap_rule=sfg.IdentityRemapRule(),
            allow_self_association=initial_state.allow_self_association,
        )
        init_rule.reset_trace()
        init_result = sfg.run_scalar_field_geometry(init_config)
        phi = np.asarray(init_result.phi[-1], dtype=np.float64).copy()
        states = init_result.states
        init_traces = init_rule.get_traces()

    soo_trace_hashes = tuple(trace.fingerprint() for trace in init_traces)
    report_passed = bool(source_trace.passed)
    if initialization.mode == "support_seeded" and initialization.require_nonzero_support_activation:
        report_passed = report_passed and source_trace.support_nonzero_count > 0
    if initialization.initialization_cycles > 0:
        report_passed = report_passed and len(init_traces) == initialization.initialization_cycles
        report_passed = report_passed and all(trace.invariants.passed for trace in init_traces)

    report = InitializationEpochReport(
        mode=initialization.mode,
        initialization_cycles=int(initialization.initialization_cycles),
        measurement_starts_after_initialization=bool(initialization.measurement_starts_after_initialization),
        initial_phi_hash=array_hash(initial_phi),
        source_trace=source_trace,
        phi_after_initialization_hash=array_hash(phi),
        soo_trace_hashes=soo_trace_hashes,
        passed=report_passed,
        details={
            "state_lineage_hash": stable_json_hash([state.fingerprint for state in states]),
            "source_added_to_initial_phi": initialization.mode == "support_seeded",
            "measurement_readouts_start_after_initialization": initialization.measurement_starts_after_initialization,
            "trace_epochs": [trace.epoch for trace in init_traces],
        },
    )

    if initialization.mode == "support_seeded" and not initialization.measurement_starts_after_initialization:
        raise ManifestError("support_seeded initialization requires measurement_starts_after_initialization=true.")
    if not report.passed:
        raise ManifestError(f"Initialization epoch failed: {report.details}")

    return InitializationResult(
        phi_after_initialization=phi,
        report=report,
        soo_traces=init_traces,
    )
