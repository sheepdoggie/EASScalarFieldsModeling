from __future__ import annotations

import argparse
import json
from pathlib import Path

from .run_manager import default_signing_key, run_signed_overlay_case


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run and sign one declarative Rank-3 overlay using the installed framework package.")
    parser.add_argument("overlay", help="Path to overlay JSON")
    parser.add_argument("output_dir", help="Directory where the signed evidence package will be written")
    parser.add_argument("--signing-key", default=str(default_signing_key()), help="Private signing key path. Default: ~/.rank3/private_key.pem")
    parser.add_argument("--required-artifact", action="append", default=[], help="Artifact that must exist after the run; may be repeated")
    args = parser.parse_args(argv)
    record = run_signed_overlay_case(
        overlay_path=Path(args.overlay),
        output_dir=Path(args.output_dir),
        private_key_path=Path(args.signing_key),
        required_artifacts=tuple(args.required_artifact),
        command="rank3-run-overlay",
    )
    print(json.dumps(record.__dict__, indent=2, sort_keys=True))
    return 0 if record.status == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
