# Enforceable Rank-3 Scalar Field Modeling Layer

This package wraps the existing `scalar_field_geometry.py` scaffold with an enforceable modeling layer.

It adds:

- model manifests
- rule metadata and rule-status enforcement
- mandatory controls
- pre-registered readouts
- result immutability wrappers
- evidence package hashes
- source-pattern audit
- executable BASE gate
- single enforced runner entry point: `run_model_package`

The raw geometry engine is still present for infrastructure work. A model that wants downstream certification/admission language must run through `rank3_enforced.run_model_package`.

## Minimal run

```bash
python run_minimal_enforced_model.py
```

Expected status:

- execution completes
- controls pass
- evidence is hashed
- result arrays are frozen
- BASE gate does not return admitted certification because the manifest verdict is `Control`

That is intentional. Control runs should execute, but they should not be certified as admitted dynamics.

## Security boundary

This is practical enforcement, not absolute security against a process that can edit or monkeypatch the core package. To make it operationally strong:

1. Install the core package as a hash-pinned wheel.
2. Do not use editable installs for the core.
3. Allow model plugins/manifests to be edited, not the core runner/audit code.
4. Set `expected_core_hash` in `ModelManifest` once the core is locked.
5. Treat any failed BASE gate as blocking downstream use.

## Enforced declarative overlay mode

Certified/candidate modeling now rejects arbitrary Python overlays. The enforced path accepts JSON overlays only and resolves all executable behavior through locked registries.

### New entry point

```python
from rank3_enforced import run_declarative_overlay

result = run_declarative_overlay("overlays/minimal_candidate_overlay.json")
```

### What is allowed in an overlay

A JSON overlay may declare:

- model type
- field size and layer count
- initial association generation rule and seed or seed set
- initial scalar field as zeros or explicit values
- graph mode and path scope
- locked phase, pair-weight, and triplet-lift rule names
- locked scalar-update and association-remap rule names
- support records, boundary points, dressing points, handedness labels, and active phase maps
- constraints such as non-overlap and three-phase coherence
- requested readouts and controls

### What is rejected

The overlay loader rejects:

- `.py` overlays
- executable overlay keys such as `python`, `function`, `lambda`, `source_code`, `exec`, `eval`, `import`, and `class`
- unknown locked rule names
- unknown locked readout names
- unsupported model types
- invalid support indices
- overlapping supports when `non_overlap_required` is true
- candidate/admission runs constructed directly as arbitrary Python `ModelPackage` objects

### Modes

- `run_model_package(...)` remains available for direct infrastructure/control packages and exploratory use.
- Candidate/admission runs must have a `compiled_overlay_hash`, which is produced only by the declarative overlay compiler.
- `run_declarative_overlay(...)` is the enforced candidate/admission-capable path.

### Included overlays

- `overlays/minimal_control_overlay.json`
- `overlays/minimal_candidate_overlay.json`
- `overlays/two_support_candidate_overlay.json`

### Locked registries

Executable behavior is selected only from registries in `rank3_enforced/locked_registries.py`:

- scalar update rules
- association remap rules
- phase rules
- pair-weight rules
- triplet-lift rules
- readout rules

New model logic must be added to the locked registry first. It cannot be smuggled into a one-off overlay.

## Declarative SOO enforcement

Candidate/certifiable SOO processing no longer requires, or accepts, an overlay-supplied Python functional. Enforced overlays may select the locked scalar-update rule:

```json
"scalar_update_rule": "soo_declarative_v0_1"
```

and must supply a data-only SOO recipe in `scalar_update_params.recipe`.

The recipe may declare locked residual operators and locked closure behavior, for example:

```json
"scalar_update_params": {
  "recipe": {
    "recipe_id": "minimal_signed_rank3_soo_recipe_v0_1",
    "residual_terms": [
      {"id": "active_contrast", "operator_id": "active_association_contrast", "weight": 0.5, "scope": "all_points"},
      {"id": "completed_balance", "operator_id": "completed_rank3_balance", "weight": 0.5, "scope": "all_points"}
    ],
    "closure": {
      "id": "linear_response",
      "response_scale": 0.05,
      "max_iterations": 1,
      "tolerance": 1e-12,
      "preserve_signed_values": true,
      "allow_zero_crossing": true,
      "forbid_clamping": true
    },
    "invariant_profile": "strict_candidate"
  }
}
```

Locked SOO residual operators currently included:

- `active_association_contrast`
- `completed_rank3_balance`
- `tensor_completion_pressure`

Locked SOO closures currently included:

- `linear_response`
- `fixed_point_damped`

Every declarative SOO transition emits an immutable `SOOUpdateTrace` with residual-term hashes, closure trace, phi hashes, geometry hash, and invariant report. The enforced runner resets the trace collector before the primary run, verifies one trace per transition, audits invariant pass/fail, and hashes the trace package into the evidence package.

The SOO recipe parser rejects executable and target-imposing keys such as `python`, `function`, `source_code`, `expected_result`, `desired_result`, `attraction`, `repulsion`, `force_path_shortening`, `force_path_lengthening`, `midpoint_collapse`, and `target_verdict`.

Included SOO overlay:

- `overlays/minimal_candidate_soo_overlay.json`

## Support-seeded initialization epoch

This package now includes a locked support-seeded initialization layer for support-bearing models.

A `two_support_path_adjustment` overlay must declare:

```json
"initialization": {
  "mode": "support_seeded",
  "start_sites": "boundary_and_dressing_points",
  "source_rule": "balanced_boundary_dressing_lift_v0_1",
  "initialization_cycles": 2,
  "require_nonzero_support_activation": true,
  "require_vacuum_zero_elsewhere": true,
  "measurement_starts_after_initialization": true
}
```

The initialization epoch builds a sealed source array from declared support boundary/dressing records, optionally runs SOO initialization cycles, and uses the resulting `phi_after_initialization` as measurement `phi_0`. Measurement readouts begin only after initialization.

See `TDD_support_seeded_initialization.md`.

## Locked framework certificate system

The package now supports signed framework evidence packages. A result is not framework-certified because a report says it used the framework; it is framework-certified only if its signed evidence envelope verifies.

### Certificate workflow

1. Generate an Ed25519 signing keypair outside the AI-editable workspace:

```bash
python -m rank3_enforced.generate_signing_key ~/.rank3/private_key.pem ~/.rank3/public_key.pem
```

Keep the private key outside output ZIPs and outside any directory an AI/operator can edit. The public key may be distributed.

2. Run and sign a declarative overlay:

```bash
python run_signed_declarative_overlay.py overlays/minimal_control_overlay.json signed_run ~/.rank3/private_key.pem
```

3. Verify the signed package:

```bash
python -m rank3_enforced.verify_certificate signed_run
```

A valid package contains:

```text
EVIDENCE_ENVELOPE.json
EVIDENCE_ENVELOPE.sig
CERTIFICATE.json
SHA256SUMS.csv
FRAMEWORK_PUBLIC_KEY.pem
```

The signed envelope covers the framework/core hash, registry hashes, compiled overlay hash, initialization trace hash, SOO trace hash, control-suite hash, raw result hash, readout hash, BASE gate hash, command hash, environment hash, and package hash.

### Certificate meaning

A valid certificate means the package was produced and packaged through the locked framework pathway without post-signature modification. It does not mean the model is scientifically admitted. Candidate/control packages may be validly signed while still reporting `admitted=false` and `base_gate_passed=false`.

### Partial-framework-use detection

If an output package lacks a valid `EVIDENCE_ENVELOPE.sig`, classify it as non-certified. It may be framework-assisted exploratory output, but it is not a certifiable framework result.

See `TDD_locked_framework_certificate_system.md`.

## Locked explicit path construction and closure readouts

The framework now supports a data-only `path_construction` overlay section using the locked rule `linear_support_path_v0_1`. The model type `two_support_explicit_path_adjustment` requires support-seeded initialization and automatically adds locked readouts:

- `center_locus_readout`
- `structural_silence_readout`
- `delta_l_classification`

These replace ad hoc Python center-locus or Delta-L scripts for candidate/certification-grade packages. See `TDD_locked_explicit_path_readouts.md` and `overlays/two_support_explicit_path_candidate_overlay.json`.

## Dual plaintext + encrypted evidence output

For workflows where the operator may inspect results but an independent verifier must receive the same evidence encrypted, use the dual-output runner.

Generate a signing keypair:

```bash
python -m rank3_enforced.generate_signing_key ~/.rank3/signing_private.pem ~/.rank3/signing_public.pem
```

Generate a recipient encryption keypair. The verifier keeps the private key and gives the public key to the runner:

```bash
python -m rank3_enforced.generate_encryption_key ~/.rank3/recipient_private.pem ~/.rank3/recipient_public.pem
```

Run a declarative overlay and emit both packages:

```bash
python run_dual_declarative_overlay.py \
  overlays/minimal_control_overlay.json \
  dual_output \
  ~/.rank3/signing_private.pem \
  ~/.rank3/recipient_public.pem
```

This creates:

```text
operator_plaintext_package.zip
verifier_encrypted_package.r3enc.json
TRANSFER_MANIFEST.json
TRANSFER_MANIFEST.sig
TRANSFER_PUBLIC_KEY.pem
TRANSFER_SHA256SUMS.csv
```

Verify public consistency without decrypting:

```bash
python -m rank3_enforced.verify_dual_package dual_output
```

Verify that the encrypted package decrypts to the same canonical signed evidence package:

```bash
python -m rank3_enforced.verify_dual_package dual_output ~/.rank3/recipient_private.pem
```

Acceptance rule: the decrypted package SHA-256 must equal `canonical_package_sha256` in `TRANSFER_MANIFEST.json`, and the decrypted inner evidence package must have a valid framework certificate.

## SOO functional reporting and diagnostic point residual traces

Every enforced run now writes `SOO_FUNCTIONAL_REPORT.json` before signing. This report identifies the scalar-update rule, declarative SOO recipe, residual terms, term weights, closure, operator classifications, and warnings when a charge-orientation test is using raw scalar smoothing operators instead of relation-complete packet operators.

The declarative SOO trace now records diagnostic point samples for compiler-selected points. For explicit support-path runs, those points include the declared center locus or center pair, support anchors, and declared boundary/dressing points. Each residual term trace records, at those points:

```text
phi_current_value
raw_residual_value
weighted_residual_value
```

The closure trace records, at the same points:

```text
total_residual_value
delta_phi_value
phi_next_value
```

A new locked residual operator is available:

```text
relation_complete_packet_contrast
```

It computes the active support packet as:

```text
chi_H,r = phi(boundary_H,r) - phi(dressing_H,r)
```

and propagates the signed packet comparison along the declared explicit path. It is a candidate operator, not an admitted final SOO law, but it prevents charge-contact tests from silently reducing to common-mode scalar smoothing. See `TDD_locked_SOO_functional_reporting.md` and `overlays/two_support_explicit_path_signed_packet_candidate_overlay.json`.
